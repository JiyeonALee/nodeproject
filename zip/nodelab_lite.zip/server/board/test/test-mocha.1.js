var assert = require('assert');

var a = 10;
var board = {writer: '김철수', title: 'mocha 테스트', content: '김철수 만세'};
var result = {writer: '김철수', title: 'mocha 테스트', content: '김철수 만세'};

// test suite
describe.skip('suite #1 동기 방식 테스트', function(){
  // unit test
  it('test #1 equal(board,result)', function(){
    assert.equal(board, result);
  });
  it('test #2 deepEqual(board,result)', function(){
    assert.deepEqual(board, result);
  });
});

describe('suite #2 비동기 함수 테스트', function(){
  this.timeout(1000*10);  // 각각의 단위테스트 제한 시간
  it('#1 a==10', function(done){
    setTimeout(function(){
      assert(a == 10);
      a++;
      done();
    }, Math.random()*10000);
  });
  it('#2 a==11', function(done){
    setTimeout(function(){
      assert(a == 11);
      a++;
      done();
    }, Math.random()*10000);
  });
  it('#3 a==12', function(done){
    setTimeout(function(){
      assert(a == 12);
      a++;
      done();
    }, Math.random()*10000);
  });
});

// board 테스트
var dao = require('../models/board');
describe.only('게시판 기능 테스트', function(){
  var newNo;
  var beforeList;

  // 테스트 시작 전 처리할 작업
  before(function(done){
    setTimeout(done, 1500);
  });

  before(function(done){
    dao.list(function(result){
      beforeList = result;
      done();
    });
  });

  describe('#1 등록 작업', function(){
    it('#1-1 등록 요청', function(done){
      dao.create(board, function(no){
        assert.equal(typeof no, 'number');
        newNo = no;
        done();
      });
    });
    it('#1-2 등록한 게시물 조회', function(done){
      dao.show(newNo, function(newBoard){
        assert.deepEqual(newBoard, board);
        done();
      });
    });
  });
  describe('#2 삭제 작업', function(){
    it('#2-1 삭제 요청', function(done){
      dao.remove(newNo, done);
    });
    it('#2-2 삭제 후 목록 조회', function(done){
      dao.list(function(result){
        assert.deepEqual(result, beforeList);
        done();
      });
    });
  });

  after(function(){
    dao.close();
  });
});