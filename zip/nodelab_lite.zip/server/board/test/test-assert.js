var assert = require('assert');

var a = 10;
var board = {writer: '김철수', title: '테스트'};
var result = {writer: '김철수', title: '테스트'};

console.log('테스트 시작.');

assert(true);
// assert(false);
assert(a == 10);
assert(a++ == 10);
assert.equal(11, a);


try{
  assert.equal(board, result);
  console.log('1. 테스트 통과.');
}catch(err){
  console.log('1. 테스트 실패.');
}

try{
  assert.deepEqual(board, result);
  console.log('2. 테스트 통과.');
}catch(err){
  console.log('2. 테스트 실패.');
}

// 하나라도 테스트를 통과 하지 못하면 
// 다음 테스트를 진행할 수 없다.
// 각각의 테스트를 독립적으로 할 수 있도록 try-catch 이용.
// 비동기 함수의 테스트가 어렵다.(특히 순서가 필요한 경우)

setTimeout(function(){
  assert.equal(board, result);
}, 1000);

console.log('테스트 통과.');