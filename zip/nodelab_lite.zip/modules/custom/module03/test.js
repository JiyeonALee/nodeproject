var m3 = require('./m3');
console.log(m3.name, m3.type);