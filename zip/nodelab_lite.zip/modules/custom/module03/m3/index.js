var obj = {
  name: 'index.js',
  "type": "folder"
};
// require() 함수의 결과로 리턴되는 값을 지정
module.exports = obj;