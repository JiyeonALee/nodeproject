var obj = {
  name: 'm3.js',
  "type": "javascript"
};
// require() 함수의 결과로 리턴되는 값을 지정
module.exports = obj;