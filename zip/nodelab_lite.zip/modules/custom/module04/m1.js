console.log('m1 로딩됨.');
console.log(__dirname);
console.log(__filename);

require('./m2');