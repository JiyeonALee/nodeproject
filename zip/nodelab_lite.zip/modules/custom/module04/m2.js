console.log('m2 로딩됨.');
console.log(__dirname);
console.log(__filename);

require('./m3');